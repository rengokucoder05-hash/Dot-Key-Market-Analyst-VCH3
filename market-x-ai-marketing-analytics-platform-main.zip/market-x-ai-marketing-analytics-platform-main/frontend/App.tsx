import React from "react";
import { ClerkProvider, SignedIn, SignedOut } from "@clerk/clerk-react";
import ChatPage from "./pages/ChatPage";
import LoginPage from "./pages/LoginPage";

const PUBLISHABLE_KEY = "pk_test_cmVsYXhpbmctYmFzaWxpc2stNTYxOS5jbGVyay5hY2NvdW50cy5kZXYk";

export default function App() {
  return (
    <ClerkProvider publishableKey={PUBLISHABLE_KEY}>
      <SignedIn>
        <ChatPage />
      </SignedIn>
      <SignedOut>
        <LoginPage />
      </SignedOut>
    </ClerkProvider>
  );
}
