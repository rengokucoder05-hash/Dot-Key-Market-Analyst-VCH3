export type ChatModel = "lite" | "analyst";
export type Market = "India" | "US" | "UK" | "UAE" | "Global" | "Southeast Asia" | "Europe";

export interface Attachment {
  type: "image" | "pdf" | "csv";
  name: string;
  data: string;
  mimeType: string;
}

export interface Message {
  id: string;
  conversationId: string;
  role: "user" | "assistant";
  content: string;
  attachments: Attachment[];
  createdAt: Date;
}

export interface Conversation {
  id: string;
  userId: string;
  title: string;
  model: string;
  market: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ChartData {
  type: "bar" | "line" | "pie";
  title: string;
  data: Array<{ name: string; value: number; fill?: string }>;
  xKey: string;
  yKey: string;
}

export interface SWOTData {
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
}

export interface TableData {
  headers: string[];
  rows: string[][];
}

export type ParsedBlock =
  | { kind: "text"; content: string }
  | { kind: "chart"; data: ChartData }
  | { kind: "swot"; data: SWOTData }
  | { kind: "table"; data: TableData };
