import React from "react";

interface AIMatrixProps {
  isThinking: boolean;
}

export default function AIMatrix({ isThinking }: AIMatrixProps) {
  return (
    <div className="relative flex items-center justify-center w-full py-6">
      {/* Floating particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 12 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: `${4 + (i % 4) * 2}px`,
              height: `${4 + (i % 4) * 2}px`,
              background: `rgba(14, 165, 233, ${0.15 + (i % 5) * 0.07})`,
              left: `${8 + i * 7}%`,
              top: `${10 + (i % 4) * 20}%`,
              animation: `float-particle ${3 + (i % 4)}s ease-in-out ${i * 0.4}s infinite`,
            }}
          />
        ))}
      </div>

      {/* Matrix orb */}
      <div className="relative flex items-center justify-center">
        {/* Outer ring */}
        <div
          className="absolute rounded-full border border-sky-200/40"
          style={{
            width: "140px",
            height: "140px",
            animation: isThinking
              ? "spin-slow 3s linear infinite"
              : "spin-slow 8s linear infinite",
          }}
        />
        {/* Middle ring */}
        <div
          className="absolute rounded-full border border-sky-300/50"
          style={{
            width: "108px",
            height: "108px",
            animation: isThinking
              ? "spin-reverse 2s linear infinite"
              : "spin-reverse 6s linear infinite",
          }}
        />
        {/* Pulse ring */}
        <div
          className="absolute rounded-full"
          style={{
            width: "90px",
            height: "90px",
            background: "radial-gradient(circle, rgba(14,165,233,0.12) 0%, transparent 70%)",
            animation: isThinking ? "pulse-ring 1s ease-in-out infinite" : "pulse-ring 2.5s ease-in-out infinite",
          }}
        />
        {/* Core orb */}
        <div
          className="relative flex items-center justify-center rounded-full z-10"
          style={{
            width: "72px",
            height: "72px",
            background: "linear-gradient(135deg, #0ea5e9 0%, #0369a1 50%, #0c4a6e 100%)",
            boxShadow: isThinking
              ? "0 0 30px rgba(14,165,233,0.6), 0 0 60px rgba(14,165,233,0.3), inset 0 1px 0 rgba(255,255,255,0.3)"
              : "0 0 20px rgba(14,165,233,0.4), 0 0 40px rgba(14,165,233,0.15), inset 0 1px 0 rgba(255,255,255,0.3)",
            animation: isThinking ? "core-pulse 1s ease-in-out infinite" : "none",
          }}
        >
          {/* MX Text */}
          <span className="text-white font-bold text-sm tracking-wider select-none">MX</span>

          {/* Inner shine */}
          <div
            className="absolute rounded-full"
            style={{
              width: "28px",
              height: "14px",
              top: "10px",
              left: "12px",
              background: "linear-gradient(135deg, rgba(255,255,255,0.4) 0%, transparent 100%)",
              borderRadius: "50%",
            }}
          />
        </div>

        {/* Data dots orbiting */}
        {isThinking &&
          Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-sky-400"
              style={{
                width: "6px",
                height: "6px",
                animation: `orbit ${1.5 + i * 0.3}s linear ${i * 0.3}s infinite`,
                transformOrigin: "0 0",
                transform: `rotate(${i * 90}deg) translateX(54px)`,
                opacity: 0.8,
              }}
            />
          ))}
      </div>

      {/* Status label */}
      <div className="absolute bottom-1 left-0 right-0 flex justify-center">
        <span
          className="text-xs font-medium tracking-widest uppercase"
          style={{ color: "rgba(14,165,233,0.7)", letterSpacing: "0.15em" }}
        >
          {isThinking ? (
            <span className="flex items-center gap-1.5">
              <span
                className="inline-block w-1.5 h-1.5 rounded-full bg-sky-400"
                style={{ animation: "blink 0.8s ease-in-out 0s infinite" }}
              />
              <span
                className="inline-block w-1.5 h-1.5 rounded-full bg-sky-400"
                style={{ animation: "blink 0.8s ease-in-out 0.2s infinite" }}
              />
              <span
                className="inline-block w-1.5 h-1.5 rounded-full bg-sky-400"
                style={{ animation: "blink 0.8s ease-in-out 0.4s infinite" }}
              />
              Analyzing
            </span>
          ) : (
            "Market X AI"
          )}
        </span>
      </div>

      <style>{`
        @keyframes float-particle {
          0%, 100% { transform: translateY(0px) scale(1); opacity: 0.4; }
          50% { transform: translateY(-12px) scale(1.2); opacity: 0.8; }
        }
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes spin-reverse {
          from { transform: rotate(360deg); }
          to { transform: rotate(0deg); }
        }
        @keyframes pulse-ring {
          0%, 100% { transform: scale(1); opacity: 0.6; }
          50% { transform: scale(1.15); opacity: 1; }
        }
        @keyframes core-pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.06); }
        }
        @keyframes orbit {
          from { transform: rotate(var(--start-angle, 0deg)) translateX(54px); }
          to { transform: rotate(calc(var(--start-angle, 0deg) + 360deg)) translateX(54px); }
        }
        @keyframes blink {
          0%, 100% { opacity: 0.3; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1.2); }
        }
      `}</style>
    </div>
  );
}
