import React from "react";
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from "recharts";
import { ChartData } from "../types/chat";

const COLORS = ["#0ea5e9", "#0369a1", "#38bdf8", "#7dd3fc", "#bae6fd", "#0c4a6e", "#1e40af", "#3b82f6"];

interface InteractiveChartProps {
  data: ChartData;
}

export default function InteractiveChart({ data }: InteractiveChartProps) {
  const chartData = data.data.map((d, i) => ({
    ...d,
    fill: d.fill || COLORS[i % COLORS.length],
  }));

  return (
    <div
      className="rounded-xl p-4 mt-3"
      style={{
        background: "rgba(255,255,255,0.7)",
        backdropFilter: "blur(12px)",
        border: "1px solid rgba(14,165,233,0.15)",
        boxShadow: "0 4px 24px rgba(14,165,233,0.08)",
      }}
    >
      <h4 className="text-sm font-semibold text-sky-800 mb-4">{data.title}</h4>
      <ResponsiveContainer width="100%" height={260}>
        {data.type === "bar" ? (
          <BarChart data={chartData} margin={{ top: 5, right: 20, bottom: 20, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,165,233,0.1)" />
            <XAxis
              dataKey={data.xKey}
              tick={{ fontSize: 11, fill: "#64748b" }}
              axisLine={{ stroke: "rgba(14,165,233,0.2)" }}
            />
            <YAxis tick={{ fontSize: 11, fill: "#64748b" }} axisLine={{ stroke: "rgba(14,165,233,0.2)" }} />
            <Tooltip
              contentStyle={{
                background: "rgba(255,255,255,0.95)",
                border: "1px solid rgba(14,165,233,0.2)",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(0,0,0,0.08)",
              }}
            />
            <Legend />
            <Bar dataKey={data.yKey} radius={[6, 6, 0, 0]} isAnimationActive>
              {chartData.map((entry, index) => (
                <Cell key={index} fill={entry.fill} />
              ))}
            </Bar>
          </BarChart>
        ) : data.type === "line" ? (
          <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 20, left: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(14,165,233,0.1)" />
            <XAxis
              dataKey={data.xKey}
              tick={{ fontSize: 11, fill: "#64748b" }}
              axisLine={{ stroke: "rgba(14,165,233,0.2)" }}
            />
            <YAxis tick={{ fontSize: 11, fill: "#64748b" }} axisLine={{ stroke: "rgba(14,165,233,0.2)" }} />
            <Tooltip
              contentStyle={{
                background: "rgba(255,255,255,0.95)",
                border: "1px solid rgba(14,165,233,0.2)",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey={data.yKey}
              stroke="#0ea5e9"
              strokeWidth={2.5}
              dot={{ r: 5, fill: "#0ea5e9", strokeWidth: 0 }}
              activeDot={{ r: 7 }}
              isAnimationActive
            />
          </LineChart>
        ) : (
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              outerRadius={100}
              dataKey={data.yKey}
              nameKey={data.xKey}
              isAnimationActive
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              labelLine={false}
            >
              {chartData.map((entry, index) => (
                <Cell key={index} fill={entry.fill || COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip
              contentStyle={{
                background: "rgba(255,255,255,0.95)",
                border: "1px solid rgba(14,165,233,0.2)",
                borderRadius: "8px",
              }}
            />
            <Legend />
          </PieChart>
        )}
      </ResponsiveContainer>
    </div>
  );
}
