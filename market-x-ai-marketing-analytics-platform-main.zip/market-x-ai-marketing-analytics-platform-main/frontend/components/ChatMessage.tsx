import React from "react";
import { User, Bot } from "lucide-react";
import { Message } from "../types/chat";
import { parseMessageContent } from "../utils/parseMessage";
import InteractiveChart from "./InteractiveChart";
import SWOTCard from "./SWOTCard";
import ComparisonTable from "./ComparisonTable";

interface ChatMessageProps {
  message: Message;
}

function TextBlock({ content }: { content: string }) {
  const lines = content.split("\n");
  return (
    <div className="space-y-1.5">
      {lines.map((line, i) => {
        if (line.startsWith("### "))
          return <h3 key={i} className="font-bold text-sky-900 mt-2 text-sm">{line.slice(4)}</h3>;
        if (line.startsWith("## "))
          return <h2 key={i} className="font-bold text-sky-900 mt-2 text-base">{line.slice(3)}</h2>;
        if (line.startsWith("# "))
          return <h1 key={i} className="font-bold text-sky-900 mt-2 text-lg">{line.slice(2)}</h1>;
        if (line.startsWith("**") && line.endsWith("**"))
          return <p key={i} className="font-semibold text-sky-900">{line.slice(2, -2)}</p>;
        if (line.startsWith("- ") || line.startsWith("• "))
          return (
            <div key={i} className="flex items-start gap-2 ml-2">
              <span className="mt-1.5 flex-shrink-0 w-1.5 h-1.5 rounded-full bg-sky-400" />
              <span className="text-sm text-slate-700 leading-relaxed">{line.slice(2)}</span>
            </div>
          );
        if (line.trim() === "") return <div key={i} className="h-1" />;
        return (
          <p key={i} className="text-sm text-slate-700 leading-relaxed">{line}</p>
        );
      })}
    </div>
  );
}

export default function ChatMessage({ message }: ChatMessageProps) {
  const isUser = message.role === "user";
  const blocks = isUser ? null : parseMessageContent(message.content);

  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : "flex-row"} mb-5`}>
      {/* Avatar */}
      <div
        className="flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center shadow-sm"
        style={
          isUser
            ? { background: "linear-gradient(135deg, #0ea5e9, #0369a1)" }
            : { background: "linear-gradient(135deg, #f0f9ff, #e0f2fe)", border: "1.5px solid rgba(14,165,233,0.25)" }
        }
      >
        {isUser ? (
          <User size={16} className="text-white" />
        ) : (
          <Bot size={16} style={{ color: "#0369a1" }} />
        )}
      </div>

      {/* Bubble */}
      <div className={`max-w-[78%] ${isUser ? "items-end" : "items-start"} flex flex-col gap-1`}>
        {isUser ? (
          <div>
            {message.attachments && message.attachments.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2 justify-end">
                {message.attachments.map((att, i) => (
                  <div
                    key={i}
                    className="flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs"
                    style={{
                      background: "rgba(14,165,233,0.15)",
                      border: "1px solid rgba(14,165,233,0.25)",
                      color: "#0369a1",
                    }}
                  >
                    {att.type === "image" && "🖼️"}
                    {att.type === "pdf" && "📄"}
                    {att.type === "csv" && "📊"}
                    {att.name}
                  </div>
                ))}
              </div>
            )}
            <div
              className="px-4 py-3 rounded-2xl rounded-tr-sm shadow-sm"
              style={{
                background: "linear-gradient(135deg, #0ea5e9, #0369a1)",
                color: "white",
              }}
            >
              <p className="text-sm leading-relaxed">{message.content}</p>
            </div>
          </div>
        ) : (
          <div
            className="px-4 py-3 rounded-2xl rounded-tl-sm shadow-sm"
            style={{
              background: "rgba(255,255,255,0.75)",
              backdropFilter: "blur(16px)",
              border: "1px solid rgba(14,165,233,0.15)",
              boxShadow: "0 2px 20px rgba(14,165,233,0.08)",
            }}
          >
            {blocks && blocks.length > 0 ? (
              <div>
                {blocks.map((block, i) => {
                  if (block.kind === "text") return <TextBlock key={i} content={block.content} />;
                  if (block.kind === "chart") return <InteractiveChart key={i} data={block.data} />;
                  if (block.kind === "swot") return <SWOTCard key={i} data={block.data} />;
                  if (block.kind === "table") return <ComparisonTable key={i} data={block.data} />;
                  return null;
                })}
              </div>
            ) : (
              <TextBlock content={message.content} />
            )}
          </div>
        )}
        <span className="text-xs text-slate-400 px-1">
          {new Date(message.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </span>
      </div>
    </div>
  );
}
