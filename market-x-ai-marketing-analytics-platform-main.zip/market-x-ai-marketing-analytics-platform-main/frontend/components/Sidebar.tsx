import React from "react";
import { Plus, MessageSquare, LogOut, TrendingUp } from "lucide-react";
import { useUser, useClerk } from "@clerk/clerk-react";
import { Conversation, Market } from "../types/chat";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const MARKETS: Market[] = ["India", "US", "UK", "UAE", "Global", "Southeast Asia", "Europe"];

interface SidebarProps {
  conversations: Conversation[];
  activeConversation: Conversation | null;
  selectedMarket: Market;
  onNewChat: () => void;
  onSelectConversation: (conv: Conversation) => void;
  onMarketChange: (market: Market) => void;
}

export default function Sidebar({
  conversations,
  activeConversation,
  selectedMarket,
  onNewChat,
  onSelectConversation,
  onMarketChange,
}: SidebarProps) {
  const { user } = useUser();
  const { signOut } = useClerk();

  const displayName = user?.fullName || user?.firstName || user?.emailAddresses[0]?.emailAddress || "User";
  const initials = displayName.slice(0, 2).toUpperCase();

  return (
    <aside
      className="flex flex-col w-72 flex-shrink-0 h-full"
      style={{
        background: "rgba(255,255,255,0.65)",
        backdropFilter: "blur(20px)",
        borderRight: "1px solid rgba(14,165,233,0.12)",
      }}
    >
      {/* Logo */}
      <div className="px-5 py-5 border-b" style={{ borderColor: "rgba(14,165,233,0.1)" }}>
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center shadow-sm flex-shrink-0"
            style={{ background: "linear-gradient(135deg, #0ea5e9, #0369a1)" }}
          >
            <TrendingUp size={18} className="text-white" />
          </div>
          <div>
            <h1 className="text-base font-bold" style={{ color: "#0369a1", letterSpacing: "-0.02em" }}>
              Market X
            </h1>
            <p className="text-xs" style={{ color: "#64748b" }}>Dot&amp;Key Analyst</p>
          </div>
        </div>
      </div>

      {/* New Chat */}
      <div className="px-4 pt-4 pb-2">
        <button
          onClick={onNewChat}
          className="w-full flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm text-white transition-all duration-200 hover:shadow-md hover:scale-[1.02] active:scale-[0.98]"
          style={{
            background: "linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%)",
            boxShadow: "0 2px 12px rgba(14,165,233,0.3)",
          }}
        >
          <Plus size={16} />
          New Conversation
        </button>
      </div>

      {/* Market Selector */}
      <div className="px-4 pb-3">
        <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: "#94a3b8" }}>
          Market Region
        </label>
        <Select value={selectedMarket} onValueChange={(v) => onMarketChange(v as Market)}>
          <SelectTrigger
            className="w-full text-sm h-9"
            style={{
              background: "rgba(240,249,255,0.8)",
              border: "1px solid rgba(14,165,233,0.2)",
              color: "#0369a1",
            }}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {MARKETS.map((m) => (
              <SelectItem key={m} value={m}>{m}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto px-3 pb-3 space-y-1">
        <p className="text-xs font-semibold uppercase tracking-wider px-2 pb-2 pt-1" style={{ color: "#94a3b8" }}>
          Recent Chats
        </p>
        {conversations.length === 0 && (
          <div className="text-center py-8">
            <MessageSquare size={28} className="mx-auto mb-2 opacity-30" style={{ color: "#0369a1" }} />
            <p className="text-xs" style={{ color: "#94a3b8" }}>No conversations yet</p>
          </div>
        )}
        {conversations.map((conv) => (
          <button
            key={conv.id}
            onClick={() => onSelectConversation(conv)}
            className="w-full text-left px-3 py-2.5 rounded-xl transition-all duration-150"
            style={{
              background: activeConversation?.id === conv.id ? "rgba(14,165,233,0.12)" : "transparent",
              border: activeConversation?.id === conv.id ? "1px solid rgba(14,165,233,0.2)" : "1px solid transparent",
            }}
          >
            <div className="flex items-start gap-2">
              <MessageSquare
                size={13}
                className="mt-0.5 flex-shrink-0 opacity-50"
                style={{ color: activeConversation?.id === conv.id ? "#0369a1" : "#64748b" }}
              />
              <div className="min-w-0">
                <p
                  className="text-xs font-medium truncate leading-relaxed"
                  style={{ color: activeConversation?.id === conv.id ? "#0369a1" : "#374151" }}
                >
                  {conv.title}
                </p>
                <p className="text-xs opacity-50 mt-0.5" style={{ color: "#64748b" }}>
                  {conv.model === "analyst" ? "Analyst" : "Lite"} · {conv.market}
                </p>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Footer */}
      <div
        className="px-4 py-4 border-t"
        style={{ borderColor: "rgba(14,165,233,0.1)", background: "rgba(240,249,255,0.5)" }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 min-w-0">
            {user?.imageUrl ? (
              <img
                src={user.imageUrl}
                alt={displayName}
                className="w-8 h-8 rounded-full flex-shrink-0 object-cover"
              />
            ) : (
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                style={{ background: "linear-gradient(135deg, #0ea5e9, #0369a1)" }}
              >
                {initials}
              </div>
            )}
            <div className="min-w-0">
              <p className="text-xs font-semibold truncate" style={{ color: "#0369a1" }}>{displayName}</p>
              <p className="text-xs" style={{ color: "#94a3b8" }}>Analyst</p>
            </div>
          </div>
          <button
            onClick={() => signOut()}
            className="p-1.5 rounded-lg transition-colors hover:bg-red-50 flex-shrink-0"
            title="Logout"
          >
            <LogOut size={14} style={{ color: "#ef4444" }} />
          </button>
        </div>
      </div>
    </aside>
  );
}
