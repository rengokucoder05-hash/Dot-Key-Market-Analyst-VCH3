import React from "react";
import { TableData } from "../types/chat";

interface ComparisonTableProps {
  data: TableData;
}

export default function ComparisonTable({ data }: ComparisonTableProps) {
  return (
    <div
      className="mt-3 rounded-xl overflow-hidden"
      style={{
        border: "1px solid rgba(14,165,233,0.15)",
        boxShadow: "0 4px 20px rgba(14,165,233,0.06)",
      }}
    >
      <div
        className="overflow-x-auto"
        style={{ background: "rgba(255,255,255,0.8)", backdropFilter: "blur(12px)" }}
      >
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "linear-gradient(90deg, rgba(14,165,233,0.1), rgba(3,105,161,0.08))" }}>
              {data.headers.map((header, i) => (
                <th
                  key={i}
                  className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider"
                  style={{ color: "#0369a1", borderBottom: "1px solid rgba(14,165,233,0.15)" }}
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.rows.map((row, ri) => (
              <tr
                key={ri}
                style={{
                  background: ri % 2 === 0 ? "rgba(255,255,255,0.6)" : "rgba(240,249,255,0.6)",
                  borderBottom: ri < data.rows.length - 1 ? "1px solid rgba(14,165,233,0.08)" : "none",
                }}
                className="transition-colors hover:bg-sky-50/40"
              >
                {row.map((cell, ci) => (
                  <td
                    key={ci}
                    className="px-4 py-3 text-xs"
                    style={{ color: ci === 0 ? "#0369a1" : "#374151", fontWeight: ci === 0 ? 600 : 400 }}
                  >
                    {cell}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
