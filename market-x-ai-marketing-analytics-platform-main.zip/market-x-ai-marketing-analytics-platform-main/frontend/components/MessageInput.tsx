import React, { useState, useRef, KeyboardEvent } from "react";
import { Send, Zap, BarChart3 } from "lucide-react";
import FileUpload from "./FileUpload";
import { Attachment, ChatModel } from "../types/chat";

interface MessageInputProps {
  onSend: (content: string, attachments: Attachment[]) => void;
  isLoading: boolean;
  selectedModel: ChatModel;
  onModelChange: (model: ChatModel) => void;
}

export default function MessageInput({
  onSend,
  isLoading,
  selectedModel,
  onModelChange,
}: MessageInputProps) {
  const [input, setInput] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSend = () => {
    const trimmed = input.trim();
    if (!trimmed && attachments.length === 0) return;
    if (isLoading) return;
    onSend(trimmed, attachments);
    setInput("");
    setAttachments([]);
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    const ta = e.target;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(ta.scrollHeight, 160)}px`;
  };

  return (
    <div
      className="rounded-2xl overflow-hidden transition-all duration-200"
      style={{
        background: "rgba(255,255,255,0.8)",
        backdropFilter: "blur(16px)",
        border: "1.5px solid rgba(14,165,233,0.2)",
        boxShadow: "0 4px 24px rgba(14,165,233,0.1)",
      }}
    >
      {/* Model tabs */}
      <div
        className="flex items-center gap-1 px-3 pt-2.5 pb-1.5"
        style={{ borderBottom: "1px solid rgba(14,165,233,0.08)" }}
      >
        <span className="text-xs font-semibold uppercase tracking-wider mr-2" style={{ color: "#94a3b8" }}>
          Model:
        </span>
        {(["lite", "analyst"] as ChatModel[]).map((m) => (
          <button
            key={m}
            onClick={() => onModelChange(m)}
            className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-all duration-200"
            style={
              selectedModel === m
                ? {
                    background: "linear-gradient(135deg, #0ea5e9, #0369a1)",
                    color: "white",
                    boxShadow: "0 2px 8px rgba(14,165,233,0.3)",
                  }
                : {
                    background: "rgba(14,165,233,0.06)",
                    color: "#64748b",
                    border: "1px solid rgba(14,165,233,0.12)",
                  }
            }
          >
            {m === "lite" ? <Zap size={11} /> : <BarChart3 size={11} />}
            {m === "lite" ? "Market X Lite" : "Market X Analyst"}
          </button>
        ))}
      </div>

      {/* File previews */}
      {attachments.length > 0 && (
        <div className="px-3 pt-2">
          <FileUpload attachments={attachments} onAttachmentsChange={setAttachments} />
        </div>
      )}

      {/* Input row */}
      <div className="flex items-end gap-2 px-3 py-2.5">
        <FileUpload
          attachments={[]}
          onAttachmentsChange={(newAtts) => setAttachments((prev) => [...prev, ...newAtts])}
        />

        <textarea
          ref={textareaRef}
          value={input}
          onChange={handleInput}
          onKeyDown={handleKeyDown}
          placeholder={
            selectedModel === "analyst"
              ? "Ask for SWOT analysis, market trends, competitor insights..."
              : "Ask about Dot&Key products, pricing, competitors..."
          }
          className="flex-1 resize-none bg-transparent outline-none text-sm placeholder-slate-400 leading-relaxed py-1"
          style={{ color: "#1e293b", minHeight: "40px", maxHeight: "160px" }}
          rows={1}
          disabled={isLoading}
        />

        <button
          onClick={handleSend}
          disabled={isLoading || (!input.trim() && attachments.length === 0)}
          className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all duration-200 hover:scale-105 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:scale-100"
          style={{
            background:
              isLoading || (!input.trim() && attachments.length === 0)
                ? "rgba(14,165,233,0.2)"
                : "linear-gradient(135deg, #0ea5e9, #0369a1)",
            boxShadow:
              isLoading || (!input.trim() && attachments.length === 0)
                ? "none"
                : "0 4px 12px rgba(14,165,233,0.4)",
          }}
        >
          <Send size={16} className="text-white" />
        </button>
      </div>
      <div className="px-4 pb-2.5">
        <p className="text-xs" style={{ color: "#94a3b8" }}>
          Press Enter to send · Shift+Enter for new line · Supports images, PDFs, CSVs
        </p>
      </div>
    </div>
  );
}
