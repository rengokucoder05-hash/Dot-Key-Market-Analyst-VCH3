import React, { useRef } from "react";
import { Paperclip, X } from "lucide-react";
import { Attachment } from "../types/chat";

interface FileUploadProps {
  attachments: Attachment[];
  onAttachmentsChange: (attachments: Attachment[]) => void;
}

export default function FileUpload({ attachments, onAttachmentsChange }: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = async (files: FileList) => {
    const newAttachments: Attachment[] = [];

    for (const file of Array.from(files)) {
      const mimeType = file.type;
      let type: "image" | "pdf" | "csv" = "image";
      let data = "";

      if (mimeType.startsWith("image/")) {
        type = "image";
        data = await readAsDataURL(file);
      } else if (mimeType === "application/pdf") {
        type = "pdf";
        data = await readAsDataURL(file);
      } else if (mimeType === "text/csv" || file.name.endsWith(".csv")) {
        type = "csv";
        data = await readAsText(file);
      }

      newAttachments.push({ type, name: file.name, data, mimeType });
    }

    onAttachmentsChange([...attachments, ...newAttachments]);
  };

  const readAsDataURL = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const readAsText = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsText(file);
    });

  const removeAttachment = (index: number) => {
    onAttachmentsChange(attachments.filter((_, i) => i !== index));
  };

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        className="hidden"
        multiple
        accept="image/*,.pdf,.csv"
        onChange={(e) => e.target.files && handleFiles(e.target.files)}
      />

      {attachments.length > 0 && (
        <div className="flex flex-wrap gap-2 px-4 pb-2">
          {attachments.map((att, i) => (
            <div
              key={i}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium"
              style={{
                background: "rgba(14,165,233,0.1)",
                border: "1px solid rgba(14,165,233,0.2)",
                color: "#0369a1",
              }}
            >
              {att.type === "image" && (
                <img
                  src={att.data}
                  alt={att.name}
                  className="w-4 h-4 rounded object-cover"
                />
              )}
              {att.type !== "image" && (
                <span>{att.type === "csv" ? "📊" : "📄"}</span>
              )}
              <span className="max-w-24 truncate">{att.name}</span>
              <button
                onClick={() => removeAttachment(i)}
                className="ml-0.5 hover:text-red-500 transition-colors"
              >
                <X size={12} />
              </button>
            </div>
          ))}
        </div>
      )}

      <button
        onClick={() => inputRef.current?.click()}
        className="p-2.5 rounded-xl transition-all duration-200 hover:scale-105"
        title="Attach files"
        style={{
          background: "rgba(14,165,233,0.08)",
          border: "1px solid rgba(14,165,233,0.15)",
          color: "#0369a1",
        }}
      >
        <Paperclip size={18} />
      </button>
    </>
  );
}
