import React from "react";
import { TrendingUp, TrendingDown, Lightbulb, AlertTriangle } from "lucide-react";
import { SWOTData } from "../types/chat";

interface SWOTCardProps {
  data: SWOTData;
}

const quadrants = [
  {
    key: "strengths" as const,
    label: "Strengths",
    icon: TrendingUp,
    bg: "rgba(16,185,129,0.08)",
    border: "rgba(16,185,129,0.25)",
    iconColor: "#059669",
    textColor: "#064e3b",
    badgeBg: "rgba(16,185,129,0.12)",
    badgeText: "#047857",
  },
  {
    key: "weaknesses" as const,
    label: "Weaknesses",
    icon: TrendingDown,
    bg: "rgba(239,68,68,0.06)",
    border: "rgba(239,68,68,0.2)",
    iconColor: "#dc2626",
    textColor: "#7f1d1d",
    badgeBg: "rgba(239,68,68,0.1)",
    badgeText: "#b91c1c",
  },
  {
    key: "opportunities" as const,
    label: "Opportunities",
    icon: Lightbulb,
    bg: "rgba(14,165,233,0.07)",
    border: "rgba(14,165,233,0.2)",
    iconColor: "#0369a1",
    textColor: "#0c4a6e",
    badgeBg: "rgba(14,165,233,0.1)",
    badgeText: "#0369a1",
  },
  {
    key: "threats" as const,
    label: "Threats",
    icon: AlertTriangle,
    bg: "rgba(245,158,11,0.07)",
    border: "rgba(245,158,11,0.25)",
    iconColor: "#d97706",
    textColor: "#78350f",
    badgeBg: "rgba(245,158,11,0.12)",
    badgeText: "#b45309",
  },
];

export default function SWOTCard({ data }: SWOTCardProps) {
  return (
    <div className="mt-3">
      <h4 className="text-sm font-semibold text-sky-800 mb-3 flex items-center gap-2">
        <span
          className="inline-flex items-center justify-center w-5 h-5 rounded text-xs font-bold text-white"
          style={{ background: "linear-gradient(135deg, #0ea5e9, #0369a1)" }}
        >
          S
        </span>
        SWOT Analysis
      </h4>
      <div className="grid grid-cols-2 gap-3">
        {quadrants.map((q) => {
          const Icon = q.icon;
          const items = data[q.key] || [];
          return (
            <div
              key={q.key}
              className="rounded-xl p-4"
              style={{
                background: q.bg,
                border: `1px solid ${q.border}`,
                backdropFilter: "blur(8px)",
              }}
            >
              <div className="flex items-center gap-2 mb-3">
                <Icon size={14} style={{ color: q.iconColor }} />
                <span className="text-xs font-bold uppercase tracking-wider" style={{ color: q.iconColor }}>
                  {q.label}
                </span>
              </div>
              <ul className="space-y-1.5">
                {items.map((item, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span
                      className="mt-1.5 flex-shrink-0 w-1.5 h-1.5 rounded-full"
                      style={{ background: q.iconColor }}
                    />
                    <span className="text-xs leading-relaxed" style={{ color: q.textColor }}>
                      {item}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          );
        })}
      </div>
    </div>
  );
}
