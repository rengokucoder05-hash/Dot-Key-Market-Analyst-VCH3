import React, { useRef } from "react";
import { BarChart3, Zap } from "lucide-react";
import { useChat } from "../hooks/useChat";
import Sidebar from "../components/Sidebar";
import AIMatrix from "../components/AIMatrix";
import ChatMessage from "../components/ChatMessage";
import TypingIndicator from "../components/TypingIndicator";
import MessageInput from "../components/MessageInput";
import { ChatModel, Market } from "../types/chat";

const SUGGESTED_PROMPTS = [
  "Show me a SWOT analysis for Dot&Key",
  "Compare Dot&Key vs top 5 competitors with pricing",
  "What are the emerging skincare trends in India 2024?",
  "Analyze sentiment for Dot&Key Vitamin C Serum",
  "Generate a go-to-market strategy for SPF products",
  "Forecast Dot&Key revenue for Q3 2025",
];

export default function ChatPage() {
  const {
    conversations,
    activeConversation,
    messages,
    isLoading,
    selectedModel,
    selectedMarket,
    messagesEndRef,
    setSelectedModel,
    setSelectedMarket,
    createConversation,
    selectConversation,
    sendMessage,
  } = useChat();

  const showWelcome = messages.length === 0;

  return (
    <div
      className="flex h-screen overflow-hidden"
      style={{
        background: "linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 40%, #ffffff 70%, #f8fafc 100%)",
      }}
    >
      {/* Background particles */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: `${3 + (i % 5) * 2}px`,
              height: `${3 + (i % 5) * 2}px`,
              background: `rgba(14, 165, 233, ${0.04 + (i % 6) * 0.02})`,
              left: `${(i * 7 + 3) % 97}%`,
              top: `${(i * 11 + 5) % 93}%`,
              animation: `bg-float ${5 + (i % 7)}s ease-in-out ${i * 0.5}s infinite`,
            }}
          />
        ))}
        <style>{`
          @keyframes bg-float {
            0%, 100% { transform: translateY(0) scale(1); opacity: 0.5; }
            50% { transform: translateY(-18px) scale(1.1); opacity: 1; }
          }
        `}</style>
      </div>

      {/* Sidebar */}
      <div className="relative z-10">
        <Sidebar
          conversations={conversations}
          activeConversation={activeConversation}
          selectedMarket={selectedMarket}
          onNewChat={createConversation}
          onSelectConversation={selectConversation}
          onMarketChange={(m) => setSelectedMarket(m as Market)}
        />

      </div>

      {/* Main Area */}
      <main className="flex-1 flex flex-col h-full overflow-hidden relative z-10">
        {/* Header */}
        <div
          className="flex items-center justify-between px-6 py-4 flex-shrink-0"
          style={{
            background: "rgba(255,255,255,0.6)",
            backdropFilter: "blur(16px)",
            borderBottom: "1px solid rgba(14,165,233,0.1)",
          }}
        >
          <div>
            <h2 className="text-base font-bold" style={{ color: "#0369a1" }}>
              {activeConversation?.title || "Market Intelligence Chat"}
            </h2>
            <p className="text-xs" style={{ color: "#94a3b8" }}>
              {selectedMarket} Market · {selectedModel === "analyst" ? "Market X Analyst" : "Market X Lite"}
            </p>
          </div>

          {/* Model indicator */}
          <div className="flex items-center gap-2">
            <div
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium"
              style={
                selectedModel === "analyst"
                  ? { background: "rgba(14,165,233,0.1)", color: "#0369a1", border: "1px solid rgba(14,165,233,0.2)" }
                  : { background: "rgba(245,158,11,0.08)", color: "#d97706", border: "1px solid rgba(245,158,11,0.2)" }
              }
            >
              {selectedModel === "analyst" ? <BarChart3 size={12} /> : <Zap size={12} />}
              {selectedModel === "analyst" ? "Analyst Mode" : "Lite Mode"}
            </div>
          </div>
        </div>

        {/* AI Matrix */}
        <div
          className="flex-shrink-0 px-6 pt-4"
          style={{ maxHeight: "180px" }}
        >
          <AIMatrix isThinking={isLoading} />
        </div>

        {/* Messages or Welcome */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          {showWelcome ? (
            <div className="flex flex-col items-center justify-center h-full max-w-2xl mx-auto text-center">
              <div
                className="w-16 h-16 rounded-2xl flex items-center justify-center mb-5 shadow-lg"
                style={{ background: "linear-gradient(135deg, #0ea5e9, #0369a1)" }}
              >
                <BarChart3 size={28} className="text-white" />
              </div>
              <h3 className="text-2xl font-bold mb-2" style={{ color: "#0369a1" }}>
                Welcome to Market X
              </h3>
              <p className="text-sm mb-8 leading-relaxed" style={{ color: "#64748b" }}>
                Your AI-powered market intelligence platform for Dot&Key. Ask anything about competitors, 
                trends, SWOT analysis, or marketing strategies.
              </p>
              <div className="grid grid-cols-2 gap-3 w-full">
                {SUGGESTED_PROMPTS.map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => sendMessage(prompt)}
                    className="text-left px-4 py-3 rounded-xl text-xs font-medium transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
                    style={{
                      background: "rgba(255,255,255,0.7)",
                      backdropFilter: "blur(12px)",
                      border: "1px solid rgba(14,165,233,0.15)",
                      color: "#374151",
                      boxShadow: "0 2px 12px rgba(14,165,233,0.06)",
                    }}
                  >
                    <span className="text-sky-400 mr-2">→</span>
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto">
              {messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} />
              ))}
              {isLoading && <TypingIndicator />}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Input */}
        <div
          className="px-6 py-4 flex-shrink-0"
          style={{ background: "rgba(255,255,255,0.4)", backdropFilter: "blur(12px)" }}
        >
          <div className="max-w-3xl mx-auto">
            <MessageInput
              onSend={sendMessage}
              isLoading={isLoading}
              selectedModel={selectedModel}
              onModelChange={(m) => setSelectedModel(m as ChatModel)}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
