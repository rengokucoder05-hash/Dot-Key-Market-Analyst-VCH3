import React from "react";
import { SignIn, SignUp } from "@clerk/clerk-react";
import { TrendingUp, BarChart3, Zap } from "lucide-react";
import { useState } from "react";

export default function LoginPage() {
  const [tab, setTab] = useState<"signin" | "signup">("signin");

  return (
    <div
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{ background: "linear-gradient(135deg, #e0f2fe 0%, #f0f9ff 50%, #ffffff 100%)" }}
    >
      <style>{`
        @keyframes particle-float {
          0%, 100% { transform: translateY(0) rotate(0deg) scale(1); opacity: 0.5; }
          33% { transform: translateY(-15px) rotate(5deg) scale(1.1); opacity: 0.9; }
          66% { transform: translateY(-8px) rotate(-3deg) scale(0.95); opacity: 0.7; }
        }
        @keyframes pulse-ring {
          0% { transform: scale(0.95); opacity: 0.6; }
          50% { transform: scale(1.05); opacity: 1; }
          100% { transform: scale(0.95); opacity: 0.6; }
        }
        .cl-card { border-radius: 20px !important; border: 1.5px solid rgba(14,165,233,0.15) !important; box-shadow: 0 8px 40px rgba(14,165,233,0.1) !important; background: rgba(255,255,255,0.85) !important; backdrop-filter: blur(20px) !important; }
        .cl-headerTitle { color: #0369a1 !important; font-weight: 700 !important; }
        .cl-formButtonPrimary { background: linear-gradient(135deg, #0ea5e9, #0369a1) !important; border-radius: 12px !important; box-shadow: 0 4px 16px rgba(14,165,233,0.4) !important; }
        .cl-formButtonPrimary:hover { transform: scale(1.01) !important; box-shadow: 0 6px 20px rgba(14,165,233,0.5) !important; }
        .cl-footerActionLink { color: #0369a1 !important; }
        .cl-formFieldInput { border-radius: 12px !important; border: 1.5px solid rgba(14,165,233,0.2) !important; background: rgba(240,249,255,0.8) !important; }
        .cl-formFieldInput:focus { border-color: rgba(14,165,233,0.5) !important; box-shadow: 0 0 0 3px rgba(14,165,233,0.1) !important; }
        .cl-socialButtonsBlockButton { border-radius: 12px !important; border: 1.5px solid rgba(14,165,233,0.15) !important; }
        .cl-dividerLine { background: rgba(14,165,233,0.15) !important; }
      `}</style>

      {/* Background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 24 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: `${4 + (i % 5) * 3}px`,
              height: `${4 + (i % 5) * 3}px`,
              background: `rgba(14, 165, 233, ${0.06 + (i % 6) * 0.03})`,
              left: `${(i * 7 + 5) % 95}%`,
              top: `${(i * 11 + 3) % 90}%`,
              animation: `particle-float ${4 + (i % 5)}s ease-in-out ${i * 0.4}s infinite`,
            }}
          />
        ))}
        <div
          className="absolute -top-32 -left-32 w-96 h-96 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(14,165,233,0.08) 0%, transparent 70%)" }}
        />
        <div
          className="absolute -bottom-24 -right-24 w-80 h-80 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(3,105,161,0.07) 0%, transparent 70%)" }}
        />
        <div
          className="absolute top-1/4 right-1/4 w-64 h-64 rounded-full"
          style={{ background: "radial-gradient(circle, rgba(14,165,233,0.05) 0%, transparent 70%)", animation: "pulse-ring 6s ease-in-out infinite" }}
        />
      </div>

      <div className="relative flex flex-col items-center gap-6 w-full max-w-md px-4">
        {/* Branding */}
        <div className="flex flex-col items-center gap-3">
          <div
            className="w-18 h-18 rounded-2xl flex items-center justify-center shadow-xl"
            style={{
              width: "72px",
              height: "72px",
              background: "linear-gradient(135deg, #0ea5e9 0%, #0369a1 100%)",
              boxShadow: "0 12px 32px rgba(14,165,233,0.45)",
            }}
          >
            <TrendingUp size={32} className="text-white" />
          </div>
          <div className="text-center">
            <h1
              className="text-3xl font-bold tracking-tight"
              style={{ color: "#0369a1", letterSpacing: "-0.04em" }}
            >
              Market X
            </h1>
            <p className="text-sm mt-1" style={{ color: "#64748b" }}>
              AI Market Analyst for Dot&amp;Key
            </p>
          </div>
          <div className="flex gap-2">
            {[
              { icon: BarChart3, label: "Deep Analysis" },
              { icon: Zap, label: "AI-Powered" },
            ].map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium"
                style={{
                  background: "rgba(14,165,233,0.08)",
                  border: "1px solid rgba(14,165,233,0.15)",
                  color: "#0369a1",
                }}
              >
                <Icon size={11} />
                {label}
              </div>
            ))}
          </div>
        </div>

        {/* Tab switcher */}
        <div
          className="flex rounded-xl p-1 w-full max-w-xs"
          style={{ background: "rgba(14,165,233,0.06)", border: "1px solid rgba(14,165,233,0.1)" }}
        >
          {(["signin", "signup"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 py-2 rounded-lg text-sm font-medium transition-all duration-200"
              style={
                tab === t
                  ? {
                      background: "linear-gradient(135deg, #0ea5e9, #0369a1)",
                      color: "white",
                      boxShadow: "0 2px 8px rgba(14,165,233,0.3)",
                    }
                  : { color: "#64748b" }
              }
            >
              {t === "signin" ? "Sign In" : "Register"}
            </button>
          ))}
        </div>

        {/* Clerk Auth Component */}
        <div className="w-full">
          {tab === "signin" ? (
            <SignIn
              appearance={{
                elements: {
                  rootBox: "w-full",
                  card: "w-full shadow-none border-0 bg-transparent p-0",
                  headerTitle: "text-sky-700 font-bold",
                  formButtonPrimary: "bg-gradient-to-r from-sky-400 to-sky-700 rounded-xl",
                },
              }}
            />
          ) : (
            <SignUp
              appearance={{
                elements: {
                  rootBox: "w-full",
                  card: "w-full shadow-none border-0 bg-transparent p-0",
                  headerTitle: "text-sky-700 font-bold",
                  formButtonPrimary: "bg-gradient-to-r from-sky-400 to-sky-700 rounded-xl",
                },
              }}
            />
          )}
        </div>

        <p className="text-center text-xs" style={{ color: "#94a3b8" }}>
          Powered by Google Gemini AI · Market X Platform v2.0
        </p>
      </div>
    </div>
  );
}
