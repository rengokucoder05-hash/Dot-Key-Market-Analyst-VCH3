import { useState, useCallback, useRef, useEffect } from "react";
import { useBackend } from "./useBackend";
import { Conversation, Message, Attachment, ChatModel, Market } from "../types/chat";

export function useChat() {
  const backend = useBackend();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState<ChatModel>("lite");
  const [selectedMarket, setSelectedMarket] = useState<Market>("India");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadConversations = useCallback(async () => {
    try {
      const res = await backend.chat.listConversations();
      setConversations(res.conversations as Conversation[]);
    } catch (err) {
      console.error("Failed to load conversations", err);
    }
  }, [backend]);

  const createConversation = useCallback(async () => {
    try {
      const conv = await backend.chat.createConversation({
        model: selectedModel,
        market: selectedMarket,
      });
      const newConv = conv as Conversation;
      setConversations((prev) => [newConv, ...prev]);
      setActiveConversation(newConv);
      setMessages([]);
      return newConv;
    } catch (err) {
      console.error("Failed to create conversation", err);
      return null;
    }
  }, [backend, selectedModel, selectedMarket]);

  const selectConversation = useCallback(async (conv: Conversation) => {
    setActiveConversation(conv);
    setSelectedModel(conv.model as ChatModel);
    setSelectedMarket(conv.market as Market);
    try {
      const res = await backend.chat.getMessages({ id: conv.id });
      setMessages(res.messages as Message[]);
    } catch (err) {
      console.error("Failed to load messages", err);
    }
  }, [backend]);

  const sendMessage = useCallback(
    async (content: string, attachments: Attachment[] = []) => {
      let conv = activeConversation;
      if (!conv) {
        conv = await createConversation();
        if (!conv) return;
      }

      setIsLoading(true);

      const tempUserMsg: Message = {
        id: `temp-${Date.now()}`,
        conversationId: conv.id,
        role: "user",
        content,
        attachments,
        createdAt: new Date(),
      };
      setMessages((prev) => [...prev, tempUserMsg]);

      try {
        const res = await backend.chat.sendMessage({
          conversationId: conv.id,
          content,
          attachments,
          model: selectedModel,
          market: selectedMarket,
        });

        setMessages((prev) =>
          prev
            .filter((m) => m.id !== tempUserMsg.id)
            .concat([res.userMessage as Message, res.assistantMessage as Message])
        );

        await loadConversations();
      } catch (err) {
        console.error("Failed to send message", err);
        setMessages((prev) => prev.filter((m) => m.id !== tempUserMsg.id));
      } finally {
        setIsLoading(false);
      }
    },
    [backend, activeConversation, createConversation, selectedModel, selectedMarket, loadConversations]
  );

  useEffect(() => {
    loadConversations();
  }, [loadConversations]);

  return {
    conversations,
    activeConversation,
    messages,
    isLoading,
    selectedModel,
    selectedMarket,
    messagesEndRef,
    setSelectedModel,
    setSelectedMarket,
    createConversation,
    selectConversation,
    sendMessage,
    loadConversations,
  };
}
