import { ParsedBlock, ChartData, SWOTData, TableData } from "../types/chat";

export function parseMessageContent(content: string): ParsedBlock[] {
  const blocks: ParsedBlock[] = [];
  const regex = /\[(CHART|SWOT|TABLE):({[\s\S]*?})\]/g;

  let lastIndex = 0;
  let match;

  while ((match = regex.exec(content)) !== null) {
    if (match.index > lastIndex) {
      const text = content.slice(lastIndex, match.index).trim();
      if (text) blocks.push({ kind: "text", content: text });
    }

    const type = match[1];
    try {
      const data = JSON.parse(match[2]);
      if (type === "CHART") blocks.push({ kind: "chart", data: data as ChartData });
      else if (type === "SWOT") blocks.push({ kind: "swot", data: data as SWOTData });
      else if (type === "TABLE") blocks.push({ kind: "table", data: data as TableData });
    } catch {
      blocks.push({ kind: "text", content: match[0] });
    }

    lastIndex = regex.lastIndex;
  }

  if (lastIndex < content.length) {
    const remaining = content.slice(lastIndex).trim();
    if (remaining) blocks.push({ kind: "text", content: remaining });
  }

  return blocks;
}
